import React from 'react'

function Contact() {
  return (
    <div style={
      {
        display: "flex",
        flexDirection: "column",
        alignContent: "center",
      }
    }>
      <h1 style={{color: "white"}}>hi there</h1>
    </div>
  )
}

export default Contact
