import React from 'react'
import './HeroSection.css'
import Navbar from '../Navbar/Navbar'
function HeroSection(){
  return (
    <div className='heroSection'>
      
    </div>
  )
}

export default HeroSection